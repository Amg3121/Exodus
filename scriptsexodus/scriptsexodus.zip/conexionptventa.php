<?php
//include "includes/exodus.inc.php";
//Solo consulta
include "exodus.con.php";
?>