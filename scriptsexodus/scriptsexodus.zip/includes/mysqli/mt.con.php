<?php

$db=  ADONewConnection('mysqli'); 
$db-> PConnect('localhost','exodus_con','1#tJa?;kg&=a','exodus_12mt');
$db-> EXECUTE("set names 'utf8'");

?>