<?php
$db = &ADONewConnection('mysqli'); 
$db ->PConnect('localhost','exodus_12mt','df78ttR44!','exodus_12mt');
$db ->EXECUTE("set names 'utf8'");
?>