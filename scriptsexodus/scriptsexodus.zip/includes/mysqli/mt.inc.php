<?php

$db=  ADONewConnection('mysqli'); 
$db-> PConnect('localhost','exodus_crud','6f2}]A@{;lWm','exodus_12mt');
$db-> EXECUTE("set names 'utf8'");

?>